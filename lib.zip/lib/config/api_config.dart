class ApiConfig {
  // 根据部署环境更改
  static const String baseUrl = 'http://localhost:8000';
  static const String predictEndpoint = '/predict';
  static const String convertEndpoint = '/convert_image';
}
